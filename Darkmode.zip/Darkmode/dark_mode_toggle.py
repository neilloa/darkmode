import ctypes
import os

# Constants
DWMWA_USE_IMMERSIVE_DARK_MODE = 20

def is_dark_mode_enabled():
    # This function checks if dark mode is currently enabled
    key = r'SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'
    try:
        import winreg
        registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
        key = winreg.OpenKey(registry, key)
        value, _ = winreg.QueryValueEx(key, 'AppsUseLightTheme')
        return value == 0
    except Exception as e:
        return False

def set_dark_mode(enabled):
    # This function sets the dark mode based on the 'enabled' parameter
    key = r'SOFTWARE\Microsoft\Windows\CurrentVersion\Themes\Personalize'
    try:
        import winreg
        registry = winreg.ConnectRegistry(None, winreg.HKEY_CURRENT_USER)
        key = winreg.OpenKey(registry, key, 0, winreg.KEY_WRITE)
        winreg.SetValueEx(key, 'AppsUseLightTheme', 0, winreg.REG_DWORD, 0 if enabled else 1)
        winreg.SetValueEx(key, 'SystemUsesLightTheme', 0, winreg.REG_DWORD, 0 if enabled else 1)
        return True
    except Exception as e:
        return False

def toggle_dark_mode():
    # This function toggles the current state of dark mode
    current_state = is_dark_mode_enabled()
    set_dark_mode(not current_state)

if __name__ == '__main__':
    toggle_dark_mode()
