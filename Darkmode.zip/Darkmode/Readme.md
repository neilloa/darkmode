# Dark Mode Toggle

This is a simple Python script that toggles the system-wide dark mode on Windows.

## How to Use

1. Run the executable file `dark_mode_toggle.exe`.

## Requirements

- Python 3.x
- PyInstaller

## Building the Executable

To build the executable file, run the following command:

```sh
pyinstaller --onefile dark_mode_toggle.py
